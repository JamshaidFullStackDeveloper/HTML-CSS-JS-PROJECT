function openSideBar() {
    document.getElementById("mySidebar").style.width = "350px";
  //   document.getElementById("main").style.marginLeft = "250px";
  }
  
  function closeSideBar() {
    document.getElementById("mySidebar").style.width = "0";
  //   document.getElementById("main").style.marginLeft= "0";
  }